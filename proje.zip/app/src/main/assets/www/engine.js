/* LA BJORN COMMERCE OS — Finansal hesaplama motoru
 * --------------------------------------------------------------
 * KURALLAR
 * - Tüm parasal tutarlar KURUŞ cinsinden tamsayıdır (1 TL = 100). Her kalem
 *   hesaplandığı anda kuruşa yuvarlanır; toplamlar yuvarlanmış kalemlerden yapılır.
 * - Girişler (satış fiyatı, alış maliyeti, komisyon, kargo, hizmet bedeli) KDV DAHİL.
 * - Kâr (muhasebesel) KDV HARİÇ tutarlardan hesaplanır. KDV ayrı bir vergi
 *   pozisyonu olarak raporlanır, kâra karışmaz.
 * - Nakit yalnızca nakit hareketlerinden (cashTx) oluşur. Hakediş tahsilatı alacağı
 *   kapatır, ikinci kez gelir yaratmaz. Stok alımı nakdi azaltır, stok varlığını artırır;
 *   gider olarak satış anında (SMM) bir kez yazılır.
 * - Stopaj, platformun kestiği peşin vergidir: hakedişi (nakdi) azaltır, kârı azaltmaz.
 * - Stok değerleme: AĞIRLIKLI ORTALAMA MALİYET (ürünün tüm stok girişlerinin
 *   toplam maliyeti / toplam giriş adedi). Tüm SMM hesaplarında aynı yöntem kullanılır.
 * - Vergi oranları ayarlardan gelir, sabit kodlanmaz. Muhasebeci doğrulaması gerekir.
 */
(function (root) {
  'use strict';

  const r = x => Math.round(x);                 // kuruşa yuvarla
  const tl = k => k / 100;
  const kurus = t => r((+t || 0) * 100);
  const haric = (dahil, oran) => r(dahil / (1 + oran / 100)); // KDV hariç tutar
  const kdvi = (dahil, oran) => dahil - haric(dahil, oran);    // içindeki KDV
  const GUN = 86400000;
  const gun = d => Math.floor(new Date(d).getTime() / GUN);

  function varsayilanAyarlar() {
    return {
      kdv: { satis: 10, alis: 10, hizmet: 20 },
      vadeGun: 7,
      platformlar: {
        trendyol:    { ad: 'Trendyol',    komisyon: 20, kargo: 7000, hizmet: 1000, stopaj: 1, aktif: true },
        hepsiburada: { ad: 'Hepsiburada', komisyon: 19, kargo: 7000, hizmet: 1000, stopaj: 1, aktif: true },
        amazon:      { ad: 'Amazon',      komisyon: 17, kargo: 7500, hizmet: 0,    stopaj: 1, aktif: true },
        n11:         { ad: 'N11',         komisyon: 18, kargo: 7000, hizmet: 0,    stopaj: 1, aktif: true },
        web:         { ad: 'Web sitesi',  komisyon: 3,  kargo: 6500, hizmet: 0,    stopaj: 0, aktif: true }
      },
      giderKategorileri: {
        reklam: 'Reklam', kira: 'Kira', personel: 'Personel', paketleme: 'Paketleme',
        yazilim: 'Yazılım / abonelik', kargo_ek: 'Ek kargo', diger_gider: 'Diğer gider'
      }
    };
  }

  // Nakit kategorileri: tip = gelir/gider etkisi sınıfı
  const NAKIT_KATEGORI = {
    hakedis:      { ad: 'Hakediş tahsilatı', sinif: 'alacak' },     // alacak → nakit, gelir değil
    hakedis_fark: { ad: 'Hakediş farkı',     sinif: 'pl' },         // beklenen ile gerçekleşen farkı
    sermaye:      { ad: 'Sermaye girişi',    sinif: 'ozkaynak' },
    ortak_cekis:  { ad: 'Ortak çekişi',      sinif: 'ozkaynak' },
    stok_alim:    { ad: 'Stok alımı',        sinif: 'varlik' },     // gider değil, stok varlığı
    borc_alim:    { ad: 'Borç / kredi alımı', sinif: 'borc' },
    borc_odeme:   { ad: 'Borç ödemesi',      sinif: 'borc' },
    vergi_odeme:  { ad: 'Vergi ödemesi',     sinif: 'vergi' },
    diger_gelir:  { ad: 'Diğer gelir',       sinif: 'pl' },
    transfer:     { ad: 'Hesaplar arası transfer', sinif: 'transfer' }
  };
  function kategoriBilgi(k, ayar) {
    if (NAKIT_KATEGORI[k]) return NAKIT_KATEGORI[k];
    const ad = (ayar && ayar.giderKategorileri && ayar.giderKategorileri[k]) || k;
    return { ad, sinif: 'pl' }; // işletme gideri
  }

  /* ---------- Stok ---------- */
  // Ürün başına: giriş adedi/maliyeti, satılan, iade (satılabilir), düzeltme → stok, ort. maliyet
  function stokDurumu(d, bugun) {
    const sonuc = {};
    for (const p of d.products) sonuc[p.id] = { girisAdet: 0, girisMaliyet: 0, satilan: 0, iadeGeri: 0, duzeltme: 0, satilan30: 0 };
    for (const m of d.movements) {
      const s = sonuc[m.productId]; if (!s) continue;
      if (m.tip === 'giris') { s.girisAdet += m.adet; s.girisMaliyet += m.adet * m.birimMaliyet; }
      else if (m.tip === 'duzeltme') s.duzeltme += m.adet;
    }
    const b = gun(bugun || Date.now());
    for (const o of d.orders) {
      if (o.durum === 'iptal') continue;
      for (const it of o.kalemler) {
        const s = sonuc[it.productId]; if (!s) continue;
        s.satilan += it.adet;
        if (b - gun(o.tarih) < 30) s.satilan30 += it.adet;
      }
    }
    for (const ri of d.returns) { const s = sonuc[ri.productId]; if (s && ri.satilabilir) s.iadeGeri += ri.adet; }
    for (const id in sonuc) {
      const s = sonuc[id];
      s.ortMaliyet = s.girisAdet ? r(s.girisMaliyet / s.girisAdet) : (d.products.find(p => p.id === id)?.maliyet || 0);
      s.stok = s.girisAdet - s.satilan + s.iadeGeri + s.duzeltme;
      s.deger = Math.max(0, s.stok) * s.ortMaliyet;
      const gunluk = s.satilan30 / 30;
      s.tukenmeGun = gunluk > 0 ? Math.floor(Math.max(0, s.stok) / gunluk) : null;
    }
    return sonuc;
  }

  /* ---------- Sipariş ekonomisi ---------- */
  function platform(ayar, kod) { return ayar.platformlar[kod] || ayar.platformlar.trendyol; }

  function siparisEkonomi(o, d, ayar, stok) {
    const k = ayar.kdv, pl = platform(ayar, o.platform);
    const komOran = o.komisyonOrani != null ? o.komisyonOrani : null;
    let brut = 0, komisyonDahil = 0, smm = 0, adet = 0;
    const kalemler = o.kalemler.map(it => {
      const p = d.products.find(x => x.id === it.productId) || {};
      const kalemBrut = r(it.birimFiyat * it.adet);
      const oran = komOran != null ? komOran : (p.komisyon != null ? p.komisyon : pl.komisyon);
      const kom = r(kalemBrut * oran / 100);
      const ortMal = stok && stok[it.productId] ? stok[it.productId].ortMaliyet : (p.maliyet || 0);
      const kSmm = haric(ortMal, k.alis) * it.adet; // SMM KDV hariç
      brut += kalemBrut; komisyonDahil += kom; smm += kSmm; adet += it.adet;
      return { ...it, brut: kalemBrut, komisyon: kom, smm: kSmm, oran };
    });
    const kargoDahil = o.kargo != null ? o.kargo : pl.kargo;
    const hizmetDahil = o.hizmet != null ? o.hizmet : pl.hizmet;
    const satisKdv = kdvi(brut, k.satis);
    const ciroNet = brut - satisKdv;
    const komisyonNet = haric(komisyonDahil, k.hizmet);
    const kargoNet = haric(kargoDahil, k.hizmet);
    const hizmetNet = haric(hizmetDahil, k.hizmet);
    const stopaj = r(ciroNet * pl.stopaj / 100);
    const katki = ciroNet - komisyonNet - kargoNet - hizmetNet - smm;
    const beklenenHakedis = brut - komisyonDahil - kargoDahil - hizmetDahil - stopaj;
    const giderKdv = (komisyonDahil - komisyonNet) + (kargoDahil - kargoNet) + (hizmetDahil - hizmetNet);
    return {
      id: o.id, adet, brut, satisKdv, ciroNet, komisyonDahil, komisyonNet, kargoDahil, kargoNet,
      hizmetDahil, hizmetNet, stopaj, smm, katki, beklenenHakedis, giderKdv,
      marj: ciroNet ? katki / ciroNet * 100 : 0, kalemler,
      vade: gun(o.teslimTarih || o.tarih) + (ayar.vadeGun || 0)
    };
  }

  /* ---------- İade etkisi ----------
   * İade edilen adet için: satış geliri ters kaydedilir, komisyon iade edilir,
   * stopaj geri alınır; satılabilirse ürün stoğa ve SMM geri döner. Gidiş kargosu
   * ve hizmet bedeli iade edilmez (siparişte kalır). İade kargosu yeni giderdir. */
  function iadeEtkisi(ri, o, eko, ayar) {
    const k = ayar.kdv;
    const kalem = eko.kalemler.find(x => x.productId === ri.productId) || eko.kalemler[0];
    if (!kalem) return null;
    const pay = Math.min(ri.adet, kalem.adet) / kalem.adet;
    const brut = r(kalem.brut * pay);
    const ciroNet = haric(brut, k.satis);
    const komDahil = r(kalem.komisyon * pay);
    const komNet = haric(komDahil, k.hizmet);
    const smm = r(kalem.smm * pay);
    const iadeKargoDahil = ri.kargo || 0;
    const iadeKargoNet = haric(iadeKargoDahil, k.hizmet);
    const stopaj = r(ciroNet * platform(ayar, o.platform).stopaj / 100);
    // Kâra etkisi (KDV hariç): -gelir +komisyon iadesi -iade kargosu + (satılabilirse SMM geri)
    const karEtkisi = -ciroNet + komNet - iadeKargoNet + (ri.satilabilir ? smm : 0);
    // Hakedişe (nakde) etkisi: -brüt +komisyon +stopaj -iade kargosu
    const hakedisEtkisi = -brut + komDahil + stopaj - iadeKargoDahil;
    const satisKdvIade = brut - ciroNet;
    return { brut, ciroNet, komDahil, komNet, smm, iadeKargoDahil, iadeKargoNet, stopaj, karEtkisi, hakedisEtkisi,
      kdvEtkisi: -satisKdvIade + (komDahil - komNet) - (iadeKargoDahil - iadeKargoNet) };
  }

  /* ---------- Hakediş alacağı ----------
   * Sipariş başına: beklenen (sipariş + iadeler) − tahsil edilen (cashTx.dagilim). */
  function alacaklar(d, ayar, stok) {
    const tahsil = {};
    for (const t of d.cashTx) {
      if (t.kategori !== 'hakedis' || !Array.isArray(t.dagilim)) continue;
      for (const a of t.dagilim) tahsil[a.orderId] = (tahsil[a.orderId] || 0) + a.tutar;
    }
    const liste = [];
    for (const o of d.orders) {
      if (o.durum === 'iptal') continue;
      const eko = siparisEkonomi(o, d, ayar, stok);
      let beklenen = eko.beklenenHakedis;
      for (const ri of d.returns.filter(x => x.orderId === o.id)) {
        const e = iadeEtkisi(ri, o, eko, ayar); if (e) beklenen += e.hakedisEtkisi;
      }
      const odenen = tahsil[o.id] || 0;
      liste.push({ orderId: o.id, no: o.no, platform: o.platform, tarih: o.tarih, durum: o.durum,
        vade: eko.vade, beklenen, odenen, kalan: beklenen - odenen });
    }
    const acik = liste.filter(x => x.kalan !== 0);
    return { liste, acik, toplam: acik.reduce((s, x) => s + x.kalan, 0) };
  }

  /* ---------- Nakit ve borç ---------- */
  function nakitDurumu(d) {
    const hesaplar = {};
    for (const a of d.accounts) hesaplar[a.id] = { ...a, bakiye: 0 };
    let toplam = 0;
    for (const t of d.cashTx) {
      if (hesaplar[t.hesapId]) hesaplar[t.hesapId].bakiye += t.tutar;
      toplam += t.tutar;
    }
    return { toplam, hesaplar: Object.values(hesaplar) };
  }

  function borcDurumu(d, bugun) {
    const b = gun(bugun || Date.now());
    const liste = d.debts.map(x => {
      const odenen = d.cashTx.filter(t => t.kategori === 'borc_odeme' && t.refId === x.id).reduce((s, t) => s - t.tutar, 0);
      const kalan = x.tutar - odenen;
      const kalanGun = x.vade ? gun(x.vade) - b : null;
      return { ...x, odenen, kalan, kalanGun, gecikti: kalan > 0 && kalanGun != null && kalanGun < 0 };
    });
    const acik = liste.filter(x => x.kalan > 0);
    return { liste, acik, toplam: acik.reduce((s, x) => s + x.kalan, 0) };
  }

  /* ---------- Dönem özeti (beklenen / muhasebesel) ---------- */
  function aralikta(tarih, bas, bit) { const g = gun(tarih); return g >= gun(bas) && g <= gun(bit); }

  function donemOzeti(d, ayar, bas, bit) {
    const stok = stokDurumu(d, bit);
    let ciro = 0, ciroNet = 0, katki = 0, siparis = 0, adet = 0, iptal = 0, kdvSatis = 0, kdvGider = 0, stopaj = 0;
    const urun = {}, gunluk = {};
    for (const o of d.orders) {
      if (!aralikta(o.tarih, bas, bit)) continue;
      if (o.durum === 'iptal') { iptal++; continue; }
      const e = siparisEkonomi(o, d, ayar, stok);
      siparis++; adet += e.adet; ciro += e.brut; ciroNet += e.ciroNet; katki += e.katki;
      kdvSatis += e.satisKdv; kdvGider += e.giderKdv; stopaj += e.stopaj;
      const gk = new Date(o.tarih).toISOString().slice(0, 10);
      gunluk[gk] = gunluk[gk] || { ciro: 0, kar: 0 };
      gunluk[gk].ciro += e.brut; gunluk[gk].kar += e.katki;
      for (const it of e.kalemler) {
        const u = urun[it.productId] = urun[it.productId] || { adet: 0, ciro: 0, katki: 0 };
        u.adet += it.adet; u.ciro += it.brut;
        // kalem katkısı: sipariş katkısını brüt payına göre dağıt
        u.katki += e.brut ? r(e.katki * it.brut / e.brut) : 0;
      }
    }
    // iadeler (iade tarihine göre)
    let iadeAdet = 0, iadeKar = 0, iadeTutar = 0;
    for (const ri of d.returns) {
      if (!aralikta(ri.tarih, bas, bit)) continue;
      const o = d.orders.find(x => x.id === ri.orderId); if (!o) continue;
      const e = iadeEtkisi(ri, o, siparisEkonomi(o, d, ayar, stok), ayar); if (!e) continue;
      iadeAdet += ri.adet; iadeKar += e.karEtkisi; iadeTutar += e.brut; kdvSatis += e.kdvEtkisi;
      const u = urun[ri.productId] = urun[ri.productId] || { adet: 0, ciro: 0, katki: 0 };
      u.katki += e.karEtkisi; u.iade = (u.iade || 0) + ri.adet;
      const gk = new Date(ri.tarih).toISOString().slice(0, 10);
      gunluk[gk] = gunluk[gk] || { ciro: 0, kar: 0 }; gunluk[gk].kar += e.karEtkisi;
    }
    // işletme giderleri (nakit hareketlerinden, P&L sınıfı)
    let giderler = 0, reklam = 0, digerGelir = 0;
    const giderDagilim = {};
    for (const t of d.cashTx) {
      if (!aralikta(t.tarih, bas, bit)) continue;
      const kb = kategoriBilgi(t.kategori, ayar);
      if (kb.sinif !== 'pl') continue;
      if (t.tutar < 0) {
        giderler += -t.tutar; giderDagilim[t.kategori] = (giderDagilim[t.kategori] || 0) - t.tutar;
        if (t.kategori === 'reklam') reklam += -t.tutar;
      } else digerGelir += t.tutar;
    }
    const netKar = katki + iadeKar - giderler + digerGelir;
    return {
      ciro, ciroNet, katki, siparis, adet, iptal, iadeAdet, iadeTutar, iadeKar, giderler, reklam, digerGelir,
      netKar, reklamSonrasiKar: katki + iadeKar - reklam,
      ortSepet: siparis ? r(ciro / siparis) : 0,
      ortSiparisKar: siparis ? r((katki + iadeKar) / siparis) : 0,
      iadeOrani: adet ? iadeAdet / adet * 100 : 0,
      kdvPozisyon: kdvSatis - kdvGider, stopaj, urun, gunluk, giderDagilim
    };
  }

  /* ---------- Sermaye özeti ---------- */
  function sermayeOzeti(d, ayar, bugun) {
    const stok = stokDurumu(d, bugun);
    const nakit = nakitDurumu(d);
    const al = alacaklar(d, ayar, stok);
    const borc = borcDurumu(d, bugun);
    const stokDegeri = Object.values(stok).reduce((s, x) => s + x.deger, 0);
    const b = gun(bugun || Date.now());
    const borc30 = borc.acik.filter(x => x.kalanGun != null && x.kalanGun <= 30).reduce((s, x) => s + x.kalan, 0);
    return {
      nakit: nakit.toplam, hesaplar: nakit.hesaplar, stokDegeri, alacak: al.toplam, borc: borc.toplam,
      netIsletme: nakit.toplam + stokDegeri + al.toplam - borc.toplam,
      kullanilabilir: nakit.toplam - borc30, borc30, stok, alacakListe: al, borcListe: borc
    };
  }

  /* ---------- Nakit akışı tahmini ---------- */
  function nakitTahmini(d, ayar, gunSayisi, bugun) {
    const s = sermayeOzeti(d, ayar, bugun);
    const b = gun(bugun || Date.now());
    const olaylar = [];
    for (const a of s.alacakListe.acik) {
      const g = Math.max(a.vade, b);
      if (g - b <= gunSayisi) olaylar.push({ gun: g, tutar: a.kalan, ad: 'Hakediş ' + (a.no || ''), tip: 'giris' });
    }
    for (const x of s.borcListe.acik) {
      if (x.kalanGun == null) continue;
      const g = Math.max(b + x.kalanGun, b);
      if (g - b <= gunSayisi) olaylar.push({ gun: g, tutar: -x.kalan, ad: 'Borç: ' + x.alacakli, tip: 'cikis', gecikti: x.gecikti });
    }
    for (const t of (d.planned || [])) {
      const g = gun(t.tarih);
      if (g >= b && g - b <= gunSayisi) olaylar.push({ gun: g, tutar: t.tutar, ad: t.ad, tip: t.tutar >= 0 ? 'giris' : 'cikis' });
    }
    olaylar.sort((x, y) => x.gun - y.gun);
    let bakiye = s.nakit, enDusuk = s.nakit, enDusukGun = b;
    for (const o of olaylar) { bakiye += o.tutar; o.bakiye = bakiye; if (bakiye < enDusuk) { enDusuk = bakiye; enDusukGun = o.gun; } }
    return { baslangic: s.nakit, bitis: bakiye, enDusuk, enDusukGun, olaylar, acik: enDusuk < 0 };
  }

  /* ---------- Birim kâr hesaplayıcı ----------
   * p (KDV dahil, kuruş): fiyat, maliyet, kargo, hizmet, paket, reklam, diger, iadeEk
   * oranlar: komisyon, satisKdv, alisKdv, hizmetKdv, iadeOrani (%) */
  function birimKar(p) {
    const s = p.satisKdv, h = p.hizmetKdv;
    const ciroNet = haric(p.fiyat, s);
    const komDahil = r(p.fiyat * p.komisyon / 100);
    const komNet = haric(komDahil, h);
    const kargoNet = haric(p.kargo || 0, h);
    const hizmetNet = haric(p.hizmet || 0, h);
    const paketNet = haric(p.paket || 0, h);
    const reklamNet = haric(p.reklam || 0, h);
    const digerNet = haric(p.diger || 0, h);
    const maliyetNet = haric(p.maliyet || 0, p.alisKdv);
    const satisKari = ciroNet - komNet - kargoNet - hizmetNet - paketNet - reklamNet - digerNet - maliyetNet;
    // İade olursa: gelir ve komisyon geri döner, ürün stoğa döner; gidiş kargosu, hizmet,
    // paket, reklam yanar + iade kargosu.
    const iadeKaybi = kargoNet + hizmetNet + paketNet + reklamNet + digerNet + haric(p.iadeEk || 0, h);
    const q = (p.iadeOrani || 0) / 100;
    const beklenenKar = r((1 - q) * satisKari - q * iadeKaybi);
    const stopaj = r(ciroNet * (p.stopaj || 0) / 100);
    const satisKdv = p.fiyat - ciroNet;
    const giderKdv = (komDahil - komNet) + ((p.kargo || 0) - kargoNet) + ((p.hizmet || 0) - hizmetNet) +
      ((p.paket || 0) - paketNet) + ((p.reklam || 0) - reklamNet) + ((p.diger || 0) - digerNet);
    const alisKdv = (p.maliyet || 0) - maliyetNet;
    return {
      ciroNet, komDahil, komNet, kargoNet, hizmetNet, paketNet, reklamNet, digerNet, maliyetNet,
      satisKari, iadeKaybi, beklenenKar, beklenenIadeMaliyeti: r(q * (satisKari + iadeKaybi)),
      marj: ciroNet ? beklenenKar / ciroNet * 100 : 0,
      roi: maliyetNet ? beklenenKar / maliyetNet * 100 : 0,
      stopaj, kdvPozisyon: satisKdv - giderKdv - alisKdv,
      nakitGiris: p.fiyat - komDahil - (p.kargo || 0) - (p.hizmet || 0) - stopaj
    };
  }
  // beklenenKar fiyata göre doğrusal: kar(P) = a + b·P
  function hedefFiyat(p, hedef) {
    const k0 = birimKar({ ...p, fiyat: 0 }).beklenenKar;
    const k1 = birimKar({ ...p, fiyat: 1000000 }).beklenenKar;
    const b = (k1 - k0) / 1000000;
    if (hedef.tip === 'tutar') return b > 0 ? r((hedef.deger - k0) / b) : null;
    // marj: kar = m · ciroNet = m · P/(1+s)
    const m = hedef.deger / 100 / (1 + p.satisKdv / 100);
    return b - m > 0 ? r(-k0 / (b - m)) : null;
  }

  /* ---------- Format ---------- */
  function fmt(k, ondalik = true) {
    const v = tl(k || 0);
    return v.toLocaleString('tr-TR', { minimumFractionDigits: ondalik ? 2 : 0, maximumFractionDigits: ondalik ? 2 : 0 }) + ' ₺';
  }
  function fmtK(k) { // kısa: 12,4 B ₺
    const v = tl(k || 0), a = Math.abs(v);
    if (a >= 1e6) return (v / 1e6).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + ' Mn ₺';
    if (a >= 1e4) return (v / 1e3).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + ' B ₺';
    return fmt(k, a < 1000);
  }

  const API = { r, tl, kurus, haric, kdvi, gun, GUN, varsayilanAyarlar, NAKIT_KATEGORI, kategoriBilgi, stokDurumu,
    siparisEkonomi, iadeEtkisi, alacaklar, nakitDurumu, borcDurumu, donemOzeti, sermayeOzeti, nakitTahmini,
    birimKar, hedefFiyat, fmt, fmtK };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.Engine = API;
})(typeof window !== 'undefined' ? window : globalThis);
