package com.labjorn.karasistani;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.window.OnBackInvokedDispatcher;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;

import java.util.Collections;
import java.util.List;

/**
 * Arayüz assets/www içindeki HTML dosyasından yüklenir; internet izni yoktur.
 * Premium (tek seferlik uygulama içi ürün, kimliği "premium") Google Play Faturalandırma ile satılır.
 */
public class MainActivity extends Activity {

    private static final String ADRES = "file:///android_asset/www/index.html";
    private static final String URUN_KIMLIGI = "premium";

    private WebView web;
    private SharedPreferences tercih;
    private BillingClient odeme;
    private ProductDetails urunDetay;
    private String fiyatMetni = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tercih = getSharedPreferences("ska", MODE_PRIVATE);

        FrameLayout kok = new FrameLayout(this);
        kok.setBackgroundColor(0xFF0B0B0F);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0B0F);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Kopru(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                jsBildir();
            }
        });
        kok.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            kok.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets cubuk = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets klavye = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(cubuk.left, cubuk.top, cubuk.right, Math.max(cubuk.bottom, klavye.bottom));
                return WindowInsets.CONSUMED;
            });
        }

        setContentView(kok);
        web.loadUrl(ADRES);

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::geri);
        }

        odemeKur();
    }

    /* ---------------- Google Play Faturalandırma ---------------- */

    private void odemeKur() {
        odeme = BillingClient.newBuilder(this)
                .setListener(this::satinAlmaGuncellendi)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        baglan();
    }

    private void baglan() {
        odeme.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult sonuc) {
                if (sonuc.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    urunSorgula();
                    satinAlimlariSorgula(false);
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Bir sonraki işlemde yeniden bağlanılır.
            }
        });
    }

    private void urunSorgula() {
        QueryProductDetailsParams p = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(URUN_KIMLIGI)
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();
        odeme.queryProductDetailsAsync(p, (sonuc, detaylar) -> {
            if (sonuc.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            List<ProductDetails> liste = detaylar.getProductDetailsList();
            if (liste == null || liste.isEmpty()) return;
            urunDetay = liste.get(0);
            ProductDetails.OneTimePurchaseOfferDetails teklif = urunDetay.getOneTimePurchaseOfferDetails();
            if (teklif != null) fiyatMetni = teklif.getFormattedPrice();
            jsBildir();
        });
    }

    private void satinAlimlariSorgula(boolean kullaniciIstedi) {
        if (!odeme.isReady()) {
            baglan();
            if (kullaniciIstedi) jsMesaj("Google Play'e bağlanılıyor, birkaç saniye sonra tekrar dene.");
            return;
        }
        odeme.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),
                (sonuc, alimlar) -> {
                    if (sonuc.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                        if (kullaniciIstedi) jsMesaj("Satın alımlar kontrol edilemedi. İnternet bağlantını kontrol et.");
                        return; // bağlantı yoksa kayıtlı durumu koru
                    }
                    boolean var = false;
                    for (Purchase a : alimlar) if (isle(a)) var = true;
                    premiumAyarla(var);
                    if (kullaniciIstedi) jsMesaj(var ? "Premium geri yüklendi." : "Bu Google hesabında Premium alımı bulunamadı.");
                });
    }

    /** Geçerli Premium alımıysa onaylar ve true döner. */
    private boolean isle(Purchase a) {
        if (!a.getProducts().contains(URUN_KIMLIGI)) return false;
        if (a.getPurchaseState() == Purchase.PurchaseState.PENDING) {
            jsMesaj("Ödemen bekleniyor. Onaylandığında Premium açılacak.");
            return false;
        }
        if (a.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return false;
        if (!a.isAcknowledged()) {
            // Onaylanmayan alımlar 3 gün içinde Google tarafından iade edilir.
            odeme.acknowledgePurchase(
                    AcknowledgePurchaseParams.newBuilder().setPurchaseToken(a.getPurchaseToken()).build(),
                    sonuc -> { });
        }
        return true;
    }

    private void satinAlmaGuncellendi(BillingResult sonuc, List<Purchase> alimlar) {
        int kod = sonuc.getResponseCode();
        if (kod == BillingClient.BillingResponseCode.OK && alimlar != null) {
            for (Purchase a : alimlar) {
                if (isle(a)) {
                    premiumAyarla(true);
                    jsMesaj("Teşekkürler! Premium açıldı.");
                }
            }
        } else if (kod == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            satinAlimlariSorgula(true);
        } else if (kod != BillingClient.BillingResponseCode.USER_CANCELED) {
            jsMesaj("Satın alma tamamlanamadı (" + kod + "). Daha sonra tekrar dene.");
        }
    }

    private void satinAlmayiBaslat() {
        if (urunDetay == null) {
            if (!odeme.isReady()) baglan(); else urunSorgula();
            jsMesaj("Mağaza bilgisi alınamadı. İnternet bağlantını kontrol edip tekrar dene.");
            return;
        }
        BillingFlowParams p = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(
                        BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(urunDetay).build()))
                .build();
        odeme.launchBillingFlow(this, p);
    }

    private void premiumAyarla(boolean var) {
        tercih.edit().putBoolean("premium", var).apply();
        jsBildir();
    }

    private boolean premiumMu() {
        return tercih.getBoolean("premium", false) || (BuildConfig.DEBUG && tercih.getBoolean("test_premium", false));
    }

    private void jsBildir() {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.premiumDurum && window.premiumDurum(" + premiumMu() + "," + JSONObject.quote(fiyatMetni) + ")", null));
    }

    private void jsMesaj(String m) {
        runOnUiThread(() -> web.evaluateJavascript("window.uygulamaMesaji && window.uygulamaMesaji(" + JSONObject.quote(m) + ")", null));
    }

    /* ---------------- Geri tuşu ve yaşam döngüsü ---------------- */

    private void geri() {
        web.evaluateJavascript("(window.geriTusu && window.geriTusu()) ? 'evet' : 'hayir'", sonuc -> {
            if (sonuc == null || !sonuc.contains("evet")) finish();
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= 33) {
            super.onBackPressed();
            return;
        }
        geri();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (odeme != null && odeme.isReady()) satinAlimlariSorgula(false);
    }

    @Override
    protected void onDestroy() {
        if (odeme != null) odeme.endConnection();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** JavaScript köprüsü. */
    private class Kopru {
        @JavascriptInterface
        public void kopyala(String metin) {
            runOnUiThread(() -> {
                ClipboardManager pano = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (pano != null) pano.setPrimaryClip(ClipData.newPlainText("Satıcı Kâr Asistanı", metin));
            });
        }

        @JavascriptInterface
        public boolean premiumMu() {
            return MainActivity.this.premiumMu();
        }

        @JavascriptInterface
        public String fiyat() {
            return fiyatMetni;
        }

        @JavascriptInterface
        public void satinAl() {
            runOnUiThread(MainActivity.this::satinAlmayiBaslat);
        }

        @JavascriptInterface
        public void geriYukle() {
            runOnUiThread(() -> satinAlimlariSorgula(true));
        }

        /** Yalnızca deneme (debug) sürümünde: satın almadan Premium ekranlarını denemek için. */
        @JavascriptInterface
        public boolean testModu() {
            return BuildConfig.DEBUG;
        }

        @JavascriptInterface
        public void testPremium(boolean acik) {
            if (!BuildConfig.DEBUG) return;
            tercih.edit().putBoolean("test_premium", acik).apply();
            jsBildir();
        }
    }
}
