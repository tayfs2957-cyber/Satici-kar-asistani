package com.labjorn.karasistani;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.window.OnBackInvokedDispatcher;
import android.view.WindowInsets;

/**
 * Uygulama tamamen çevrimdışıdır: arayüz assets/www içindeki HTML dosyasından yüklenir,
 * internet izni yoktur, veriler yalnızca cihazdaki WebView depolamasında tutulur.
 */
public class MainActivity extends Activity {

    private static final String ADRES = "file:///android_asset/www/index.html";
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout kok = new FrameLayout(this);
        kok.setBackgroundColor(0xFF0B0B0F);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0B0F);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // localStorage: ürünler ve ayarlar
        s.setTextZoom(100);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Kopru(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Uygulama dışındaki hiçbir adrese gidilmez.
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        kok.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Android 11+ : içerik sistem çubuklarının altına girmesin, klavye alanları kapatmasın.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            kok.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets cubuk = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets klavye = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(cubuk.left, cubuk.top, cubuk.right, Math.max(cubuk.bottom, klavye.bottom));
                return WindowInsets.CONSUMED;
            });
        }

        setContentView(kok);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(ADRES);
        }

        // Android 13+ geri hareketi (Android 16'da onBackPressed çağrılmaz).
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::geri);
        }
    }

    /** Önce sayfaya sorar: açık pencere veya alt ekran varsa onu kapatır, yoksa uygulamadan çıkar. */
    private void geri() {
        web.evaluateJavascript("(window.geriTusu && window.geriTusu()) ? 'evet' : 'hayir'", sonuc -> {
            if (sonuc == null || !sonuc.contains("evet")) {
                finish();
            }
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= 33) {
            super.onBackPressed();
            return;
        }
        geri();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    /** JavaScript köprüsü: yalnızca panoya kopyalama. */
    private class Kopru {
        @JavascriptInterface
        public void kopyala(String metin) {
            runOnUiThread(() -> {
                ClipboardManager pano = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (pano != null) {
                    pano.setPrimaryClip(ClipData.newPlainText("Satıcı Kâr Asistanı", metin));
                }
            });
        }
    }
}
