# Satıcı Kâr Asistanı (Android)

Pazaryeri satıcıları için **internetsiz** kâr ve fiyat aracı. Sunucu yok, internet izni yok, veri toplamaz.

**Araçlar:** Net kâr hesaplama (KDV hariç, tüm giderler düşülür) · Kaça satmalıyım (hedef marj veya ₺ kâr) · İndirim/kampanya kontrolü · Pazaryeri karşılaştırma · Ürünlerim listesi · Başlık oluşturucu (şablon) · Ayarlar (komisyon, kargo, KDV).

## Proje yapısı
```
app/src/main/assets/www/index.html   Uygulama arayüzü (HTML/JS, tek dosya)
app/src/main/assets/www/engine.js    Hesaplama motoru (kuruş bazlı, birim testli)
app/src/main/java/.../MainActivity.java  WebView sarmalayıcı (bağımlılıksız)
.github/workflows/android.yml        GitHub'da otomatik derleme
docs/gizlilik.html                   Play Store için gizlilik politikası
magaza/                              Simge, tanıtım görseli, ekran görüntüleri
```

## Telefondan derleme (GitHub Actions)
1. Kod GitHub deposuna yüklendiğinde (main dalına her gönderimde) derleme kendiliğinden başlar.
2. GitHub uygulamasında veya tarayıcıda depo → **Actions** → en son "Android derleme" çalışması.
3. Bittiğinde (yaklaşık 5 dk) en altta **Artifacts** → `deneme-apk` dosyasını indir, zip'i açıp APK'yi kur.
   - Telefon "bilinmeyen kaynak" uyarısı verirse o kaynağa bir kerelik izin ver.
   - Deneme APK'si her derlemede farklı geçici anahtarla imzalanır; yeni sürümü kurmadan önce eskisini kaldır.

## Play Store için imzalı paket (AAB)
Depo → Settings → Secrets and variables → Actions → şu 4 gizli değeri ekle:
`KEYSTORE_B64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Eklendikten sonraki her derlemede `play-store-aab` dosyası da üretilir; bunu Play Console'a yükle.
İmza anahtarını kaybetme: güncellemeler aynı anahtarla imzalanmalıdır (Play App Signing açıksa yükleme anahtarı Google desteğiyle sıfırlanabilir).

## Yeni sürüm yayınlarken
`app/build.gradle` içinde `versionCode` değerini 1 artır (2, 3, …), `versionName`'i güncelle.

## Play Console kontrol listesi
- Geliştirici hesabı (tek seferlik 25 $) ve kimlik doğrulama
- Yeni kişisel hesaplarda: 12 test kullanıcısıyla 14 gün kesintisiz kapalı test
- Gizlilik politikası adresi (`docs/gizlilik.html` → GitHub Pages ile yayınla; e-posta adresini doldur)
- Veri güvenliği formu: "Veri toplanmıyor / paylaşılmıyor"
- İçerik derecelendirmesi anketi, hedef kitle (18+ / genel), reklam yok
- Mağaza görselleri: `magaza/` klasöründe (512×512 simge, 1024×500 tanıtım görseli, 1080×1920 ekran görüntüleri)

Hesaplamalar tahminidir; vergi oranlarını muhasebecinle doğrula.
